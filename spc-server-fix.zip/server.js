// ============================================
// The Soft Power Collective — Static Site Server
// ============================================
// Serves the static site, proxies email signups to Kit, and receives
// contact form submissions (emailed to Casey through Resend, with a copy
// logged to stdout as a backup in Railway logs).
// ============================================

require('dotenv').config();

const express = require('express');
const compression = require('compression');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
app.set('trust proxy', 1);
const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const KIT_API_KEY = process.env.KIT_API_KEY;
const KIT_FORM_ID = process.env.KIT_FORM_ID || '9335347';

// Contact form notifications (Resend). All three are set in Railway.
const RESEND_API_KEY = process.env.RESEND_API_KEY;
const CONTACT_TO_EMAIL = process.env.CONTACT_TO_EMAIL;
const CONTACT_FROM_EMAIL =
  process.env.CONTACT_FROM_EMAIL ||
  'The Soft Power Collective <onboarding@resend.dev>';
const CONTACT_EMAIL_READY = Boolean(RESEND_API_KEY && CONTACT_TO_EMAIL);

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const VALID_SOURCES = [
  'home', 'about', 'programs', 'book-club',
  'the-collective', 'quiz', 'contact-form',
];

// ============================================
// Security headers
// ============================================
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com'],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", 'data:', 'https:'],
        connectSrc: ["'self'"],
        formAction: ["'self'"],
        frameSrc: ["'self'"],
      },
    },
    crossOriginEmbedderPolicy: false,
  })
);

app.use(compression());
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// ============================================
// Rate limiters
// ============================================
const subscribeLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Try again in a minute.' },
});

const contactLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Try again later.' },
});

// ============================================
// Kit (ConvertKit) subscription proxy
// ============================================
app.post('/api/subscribe', subscribeLimiter, async (req, res) => {
  const email = req.body.email_address || req.body.email;
  const source = req.body.source || '';

  if (!email || !EMAIL_RE.test(email)) {
    return res.status(400).json({ error: 'Valid email required' });
  }

  if (source && !VALID_SOURCES.includes(source)) {
    return res.status(400).json({ error: 'Invalid source' });
  }

  if (!KIT_API_KEY) {
    console.error('KIT_API_KEY not set');
    return res.status(500).json({ error: 'server not configured' });
  }

  try {
    const kitResp = await fetch(
      `https://api.convertkit.com/v3/forms/${KIT_FORM_ID}/subscribe`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          api_key: KIT_API_KEY,
          email,
          fields: source ? { source } : {},
        }),
      }
    );

    const data = await kitResp.json().catch(() => ({}));
    if (!kitResp.ok) {
      console.error('Kit API error:', kitResp.status, data);
      return res
        .status(kitResp.status)
        .json({ error: data.message || 'Kit API error' });
    }

    return res.json({ success: true });
  } catch (err) {
    console.error('Subscribe proxy error:', err);
    return res.status(500).json({ error: 'subscription failed' });
  }
});

// ============================================
// Contact form notification email
// Sends the full submission to Casey's inbox. Reply-To is the sender,
// so replying to the notification replies straight to the person.
// Returns true when Resend accepted the email.
// ============================================
async function sendContactEmail({ name, email, inquiry, message, time }) {
  if (!CONTACT_EMAIL_READY) return false;

  const oneLine = (value) => String(value).replace(/[\r\n]+/g, ' ').trim();
  const topic = inquiry ? oneLine(inquiry) : 'not specified';

  const resp = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: CONTACT_FROM_EMAIL,
      to: [CONTACT_TO_EMAIL],
      reply_to: email,
      subject: `New website message from ${oneLine(name)}`,
      text: [
        'Someone filled out the contact form on thesoftpowercollective.com.',
        '',
        `Name: ${oneLine(name)}`,
        `Email: ${email}`,
        `Inquiry: ${topic}`,
        `Received: ${time}`,
        '',
        'Message:',
        message,
        '',
        'Reply to this email to answer them directly.',
      ].join('\n'),
    }),
    signal: AbortSignal.timeout(8000),
  });

  if (!resp.ok) {
    const detail = await resp.text().catch(() => '');
    throw new Error(`Resend responded ${resp.status}: ${detail.slice(0, 300)}`);
  }
  return true;
}

// ============================================
// Contact form endpoint
// Emails the submission to Casey, subscribes the sender to Kit with
// source "contact-form", and logs a copy to stdout (Railway logs) so
// nothing is lost if the email fails.
// ============================================
app.post('/api/contact', contactLimiter, async (req, res) => {
  const { name, email, inquiry, message } = req.body;

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Name, email, and message are required' });
  }

  if (
    typeof name !== 'string' || name.length > 200 ||
    typeof email !== 'string' || email.length > 254 ||
    typeof message !== 'string' || message.length > 5000 ||
    (inquiry && (typeof inquiry !== 'string' || inquiry.length > 100))
  ) {
    return res.status(400).json({ error: 'Input too long' });
  }

  if (!EMAIL_RE.test(email)) {
    return res.status(400).json({ error: 'Valid email required' });
  }

  const time = new Date().toISOString();

  console.log('--- CONTACT FORM SUBMISSION ---');
  console.log('Name:', name);
  console.log('Email:', email);
  console.log('Inquiry:', inquiry || 'not specified');
  console.log('Message:', message);
  console.log('Time:', time);
  console.log('------------------------------');

  const notify = sendContactEmail({ name, email, inquiry, message, time })
    .then((sent) => {
      if (sent) {
        console.log('Contact notification emailed to inbox.');
      } else {
        console.warn(
          'CONTACT EMAIL NOT SENT: RESEND_API_KEY or CONTACT_TO_EMAIL is not set. The message above exists only in these logs.'
        );
      }
    })
    .catch((err) => {
      console.error(
        'CONTACT EMAIL FAILED. The message above exists only in these logs.',
        err.message
      );
    });

  const kit = KIT_API_KEY
    ? fetch(`https://api.convertkit.com/v3/forms/${KIT_FORM_ID}/subscribe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          api_key: KIT_API_KEY,
          email,
          first_name: name,
          fields: { source: 'contact-form' },
        }),
        signal: AbortSignal.timeout(8000),
      }).catch((err) => {
        console.error('Kit subscribe from contact form failed:', err);
      })
    : Promise.resolve();

  await Promise.all([notify, kit]);

  return res.json({ success: true });
});

// ============================================
// Static assets & page routing
// ============================================
app.use(
  express.static(PUBLIC_DIR, {
    extensions: ['html'],
    maxAge: '1d',
  })
);

app.get('/:page', (req, res, next) => {
  const page = req.params.page;
  if (!/^[a-z0-9-]+$/i.test(page)) {
    return next();
  }
  const file = path.join(PUBLIC_DIR, `${page}.html`);
  res.sendFile(file, (err) => {
    if (err) next();
  });
});

app.use((req, res) => {
  res.status(404).sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🌿 The Soft Power Collective is live on port ${PORT}`);
  console.log(`   Local:  http://localhost:${PORT}\n`);
  if (!KIT_API_KEY) {
    console.warn(
      '   ⚠️  KIT_API_KEY not set — email signups will return 500 until you configure it.\n'
    );
  }
  if (!CONTACT_EMAIL_READY) {
    console.warn(
      '   ⚠️  RESEND_API_KEY or CONTACT_TO_EMAIL not set. Contact form messages will only be written to these logs.\n'
    );
  }
});
